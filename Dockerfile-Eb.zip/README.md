Elastic Beanstalk Docker demo

Quick local test

```bash
docker build -t eb-demo-nginx .
docker run --rm -p 8080:80 eb-demo-nginx
# open http://localhost:8080
```

Quick deploy with EB CLI

```bash
pip install awsebcli --upgrade
eb init -p docker my-eb-app --region YOUR_REGION
eb create my-eb-env
eb deploy
```

Notes:
- Ensure AWS credentials are configured (`aws configure`).
- This repo contains a simple `Dockerfile` that serves `index.html` with nginx.
