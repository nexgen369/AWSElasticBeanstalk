from flask import Flask

application = Flask(__name__)

@application.route('/')
def hello():
    return "Hello Everyone from Elastic Beanstalk i am the Output of Python environment! Work-Shop completed"

if __name__ == "__main__":
    application.run(host="0.0.0.0")